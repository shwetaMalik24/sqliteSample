//
//  InsertViewController.swift
//  sqliteDemo
//
//  Created by Drish on 15/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class InsertViewController: UIViewController {
    @IBOutlet var txtAge: UITextField!
    @IBOutlet var txtName: UITextField!
     var db:DBHelper = DBHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnSave(_ sender: UIButton) {
        var Age = Int(txtAge.text!)
        db.insert(id: 0, name: txtName.text!, age: Age!)
       let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "DisplayVC") as! ViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        txtAge.text = ""
        txtName.text = ""
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
