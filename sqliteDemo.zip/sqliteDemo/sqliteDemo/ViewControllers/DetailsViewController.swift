//
//  DetailsViewController.swift
//  sqliteDemo
//
//  Created by Drish on 16/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    var id: Int32?
    var data : Person?
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtAge: UITextField!
    var db:DBHelper = DBHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        var data =  db.contact(id: id!)
        // Do any additional setup after loading the view.
        txtName.text = data?.name as String?
        txtAge.text = String(data!.age)
    }
    
    @IBAction func btnUpdate(_ sender: Any) {
       var result =  db.update(name: (txtName?.text!)! as NSString, id: Int32(id!), age: Int32(txtAge.text!)!)
        if(result == 1){
            navigationController?.popViewController(animated: false)
        }
    }
    @IBAction func btnDelete(_ sender: Any) {
        var result = db.deleteByID(id: id!)
        if(result == 1){
            navigationController?.popViewController(animated: false)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
