//
//  ViewController.swift
//  sqliteDemo
//
//  Created by Drish on 15/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//
import UIKit
import SQLite3
class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    @IBOutlet var tableViewPerson: UITableView!
    var db:DBHelper = DBHelper()
    var persons:[Person] = []
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
    }
    override func viewWillAppear(_ animated: Bool) {
          persons = db.read()
          tableViewPerson.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return persons.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! PersonCell
        cell.lblPerson?.text =  persons[indexPath.row].name as String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "DetailVC") as? DetailsViewController
        controller?.id = persons[indexPath.row].id
        self.navigationController?.pushViewController(controller!, animated: true)
    }
}

