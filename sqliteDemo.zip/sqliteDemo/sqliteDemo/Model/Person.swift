//
//  Person.swift
//  sqliteDemo
//
//  Created by Drish on 15/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import Foundation
class Person
{
   let id: Int32
    let name: NSString
    let age: Int32
    init(id:Int32, name:NSString, age:Int32)
    {
        self.id = id
        self.name = name
        self.age = age
    }
}
